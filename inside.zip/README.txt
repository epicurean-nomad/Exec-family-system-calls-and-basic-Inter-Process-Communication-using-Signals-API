For running the file:
    >> cd Q1
    >> make

Explanation of code:

    q1.c : Declares a void handler function "sig_handler()"
           
           Creates a fork() with child process S1
           
           S1 contains the struct "sigaction handler". This struct along with the handler function and the "sigaction()" syscall acts as the reciever for signals in this c file.

           Parent process of S1 forks to create two more child processes SR and ST.
           Both PID's are stored in variables SR_pid and ST_pid respectively.
	   
	   SR and ST child processes link to E1.c and E2.c respectively using "execl()" syscall

    E1.c : Contains a void function "randomNumGen()" for generating random number using the inline assembly code RDRAND
	   
	   With the help of a handler function sr_handler() containing the sigqueue() syscall, E1.c sends the value of random number back to q1.c along with the SIGTERM signal.

	   This signal is caught by the reciever handler function "sig_handler" in q1.c and the value of random number is printed out to the screen.

    E2.c : Contains a void function "rdtsc()" for reading timestamp from cpu timestamp counter using the inline assembly code RDTSC

	   Converts the obtained timestamp into human readable time string.
	   
	   With the help of a handler function st_handler() containing the sigqueue() syscall, E2.c sends the value of the timestamp back to s1 along with the SIGTERM signal

	   This signal is caught by the reciever handler function "sig_handler" in q1.c and the human readable time string is printed out to the screen. 