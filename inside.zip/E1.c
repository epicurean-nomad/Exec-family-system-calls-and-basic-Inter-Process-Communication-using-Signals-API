#include <signal.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>
#include <time.h>
#include <limits.h>

int pid = 0;
static inline unsigned int randomNumGen(){
    unsigned int rd;
    asm volatile ("RDRAND %%rax" :"=r"(rd));
    printf("Random number: %d\n",rd);
    return rd;
}

static void sr_handler(int sig, siginfo_t *info,void *extra){
    //signal = SIGALRM;
    union sigval value;
    value.sival_int = randomNumGen();


    //printf("%d\n",value.sival_int);
  //  value.sival_ptr = NULL;
    
   /*  if(sigqueue(pid, SIGTERM, value) == 0) {
        printf("signal sent successfully!!\n");
    } else {
      //  printf("%d\n",sigqueue(pid, SIGTERM, value));
        perror("SIGSENT-ERROR:");
    } */

    sigqueue(pid, SIGTERM, value);
} 

int main(int argc, char const *argv[])
{
   // sscanf(argv[1], "%d", pid);

    //printf("%d\n", pid);
    //printf("S1 in SR %s\n", argv[1]);
    
    //sigqueue(pid, SIGTERM, value);
    
    pid = atoi(argv[1]);

    struct sigaction handler;
    handler.sa_flags = SA_RESTART;
    handler.sa_sigaction = &sr_handler;

   
   // sscanf(argv[1], "%d", pid);
   // printf("%d\n",pid);
    
    sigaction(SIGALRM,&handler,NULL);
    
    struct itimerval struct_sr;
    struct_sr.it_value.tv_sec = 2;
    struct_sr.it_value.tv_usec = 0;
    struct_sr.it_interval = struct_sr.it_value;
    
    setitimer(ITIMER_REAL,&struct_sr,NULL);
    while(1){} 
 
}
