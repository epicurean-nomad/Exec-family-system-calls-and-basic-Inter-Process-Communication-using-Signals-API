#include <signal.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>
#include <time.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <errno.h>
#include <stdlib.h>
int pid = 0;
static inline uint64_t rdtsc()
{
    // uint64_t ret;
    // asm volatile ( "rdtsc" : "=A"(ret));
    // //printf("Datetime: %llu\n",ret);
    // return ret;

    uint32_t low, high;
    asm volatile("rdtsc":"=a"(low),"=d"(high));
    return ((uint64_t)high << 32) | low;
}

static void st_handler(int sig, siginfo_t *info,void *extra){
    //signal = SIGALRM;
    union sigval value;
    value.sival_int = -1;
    int sec = rdtsc()/2400020000,h,m,s;
    printf("Input seconds: %d\n");
    h = (sec/3600); 
	m = (sec -(3600*h))/60;
	s = (sec -(3600*h)-(m*60));
    
    printf("H:M:S - %d:%d:%d\n",h,m,s);

    //printf("%d\n",value.sival_int);
  //  value.sival_ptr = NULL;
    
   /*  if(sigqueue(pid, SIGTERM, value) == 0) {
        printf("signal sent successfully!!\n");
    } else {
      //  printf("%d\n",sigqueue(pid, SIGTERM, value));
        perror("SIGSENT-ERROR:");
    } */

    sigqueue(pid, SIGTERM, value);
} 

int main(int argc, char const *argv[])
{
   // sscanf(argv[1], "%d", pid);

    //printf("%d\n", pid);
    //printf("S1 in SR %s\n", argv[1]);
    
    //sigqueue(pid, SIGTERM, value);
    
    pid = atoi(argv[1]);

    struct sigaction handler;
    handler.sa_flags = SA_RESTART;
    handler.sa_sigaction = &st_handler;

   
   // sscanf(argv[1], "%d", pid);
   // printf("%d\n",pid);
    
    sigaction(SIGALRM,&handler,NULL);
    
    struct itimerval struct_st;
    struct_st.it_value.tv_sec = 2;
    struct_st.it_value.tv_usec = 0;
    struct_st.it_interval = struct_st.it_value;
    
    setitimer(ITIMER_REAL,&struct_st,NULL);
    while(1){} 
 
}
