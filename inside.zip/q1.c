#include <signal.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>


static void sig_handler(int x,siginfo_t *info,void *extra){
    int val = info->si_value.sival_int;
    printf("Caught signal %u\n", val);
}


int main(int argc, char const *argv[])
{
    pid_t S1_pid = fork();
    switch(S1_pid){
    case 0: //Child Process
    {
        printf("S1 in Main pid %d\n",getpid());
        struct sigaction handler;
        handler.sa_flags = SA_SIGINFO;
        handler.sa_sigaction = &sig_handler;
        
        sigaction(SIGTERM,&handler,NULL);

        while (1){};
    }
    case -1: //Error
    {
        return -1;
    }
    default: //Parent process
    {
        pid_t ST_pid = fork();
        switch(ST_pid){
            case 0: //Child Process
            {
                printf("print pid %d\n",getpid());
                char pid[10];
                snprintf(pid,sizeof(pid),"%d",S1_pid);
                char*args[] = {"./E2",NULL};
                execl(args[0],args[0],pid,NULL);

                
                while (1){};
            }
            case -1: //Error
            {
                return-1;
            }
            default: //Parent Process
            {
                pid_t SR_pid = fork();
                switch(SR_pid){

                case 0:
                    {
                        printf("print pid %d\n",getpid());
                        char pid2[10];
                        snprintf(pid2,sizeof(pid2),"%d",S1_pid);
                        char*args[] = {"./E1",NULL};
                        execl(args[0],args[0],pid2,NULL);
                        
                    }
                case -1: //Error
                    {
                        return -1;
                    }
                default: //Parent Process
                    {

                    }
            }

            
        }    
    }
}
    }
}


